package com.hn.tgu.hospital.usuarios_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsuariosServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
