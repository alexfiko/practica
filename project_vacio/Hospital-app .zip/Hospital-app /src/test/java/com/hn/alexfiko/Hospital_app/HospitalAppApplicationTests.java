package com.hn.alexfiko.Hospital_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
