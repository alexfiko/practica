package com.hn.tgu.hospital.especialidad_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EspecialidadServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
