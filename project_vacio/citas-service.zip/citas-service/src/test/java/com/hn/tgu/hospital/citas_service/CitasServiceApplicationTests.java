package com.hn.tgu.hospital.citas_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitasServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
